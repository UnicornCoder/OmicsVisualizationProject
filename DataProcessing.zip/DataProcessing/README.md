# OmicsVisualizationProject
This repository contains all the files used in the visualization assignment for the course "Management of Large-Scale Omics Data" (I0U19a) of KULeuven in the academic course 2015-2016.
